//
//  Main.swift
//  front
//
//  Created by Romeo De la garza on 15/03/24.
//

import SwiftUI

struct Main: View {
    var body: some View {
        ZStack {
            NavigationStack{
                navigationToAreas()
            }
        }
    }
}

#Preview {
    Main()
}
