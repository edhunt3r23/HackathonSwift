//
//  frontApp.swift
//  front
//
//  Created by Romeo De la garza on 15/03/24.
//

import SwiftUI

@main
struct frontApp: App {
    var body: some Scene {
        WindowGroup {
            Main()
        }

    }
}
